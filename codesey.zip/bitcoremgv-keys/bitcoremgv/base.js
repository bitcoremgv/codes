






var bs58 = require ( "bs58"  )   ;



var



base58

    =

        "uutm" ;









var base    =

  /*
        parseInt (


      */


 bs58 . decode( base58 )




   /*     . toString( 16 )         */    
       /*   */




  /*

                                       , 16)

                                            */








  ;







 console. log   (
     base








      )     ;
