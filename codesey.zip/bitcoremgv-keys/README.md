# bitcoremgv
this is clone of bitcore it is intended to be volatile and not pre mined
bitcore CAN BE USED TO PAY
used as a reserve
and as speculation


it is BTC and is related to LTC DOGE ETH ripple

bitcore is tested and used


this
it is not tested

and it needs to be tested to be use

 the goal is volatility

 volatility is a week of hourly high AND low of the
 moving average of 100000 MGV
 are three     the 3 months moving average

  MOVING AVERAGE IS the trailing average

 the mean is to subsidy volatility

the money is 200 000 000 000
1 WOULD BE REASONNABLE at 1 cent of euro USD CAD

no halving subsidy
1000 subsidy per block
77 seconds per block


to contribute
you can either fork bitcore   we have not asked to tell you that
we may use it but may not notice it we are not related directly
or fork this and make a pull request
the pull request here need to be obvious things

the honesty is intended
please check your locaal regulation


    it needs an algorithm that defines the subsidy

    for the worth
    3 is normal
    9 is top
    1 is

for week 3 1 3 9   subsidy is   2000
    3 3 3 3  subsidy is   1000
it calculate the length of the derivate of the hourly trailing average of 100000
3 1 3 9 is the top
and is 1000 for
3 1 3 10
3 0 3 9

3 3 3 3 is no volatility
